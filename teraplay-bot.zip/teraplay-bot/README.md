# TeraPlay Bot (Vercel-ready)

This repository contains a minimal Telegram bot that takes a Terabox (or Telegram) link
from users and replies with an iTeraPlay playable link.

## Files
- `api/index.js` - Vercel serverless function containing the bot logic.
- `package.json` - Node.js project file with dependencies.
- `vercel.json` - Vercel configuration.
- `.env.example` - Example environment variable file.

## Setup (recommended: Vercel deployment)
1. Create a GitHub repo and push these files.
2. Connect the repo to Vercel and deploy.
3. In Vercel project settings -> Environment Variables add:
   - `BOT_TOKEN` = your Telegram bot token (keep it secret!)
4. Deploy the project.
5. Set Telegram webhook (replace placeholders):
   ```
   https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook?url=https://<YOUR_VERCEL_APP>.vercel.app
   ```
6. Test your bot by sending messages in Telegram.

## Local testing (optional)
- You can run locally using `vercel dev` or `node` with a small express wrapper.
- Do NOT commit your `.env` with real token to git.

## Notes
- The bot replies with iTeraPlay player link; downloading direct MP4 may require extra parsing or a backend proxy.
- This project intentionally **does not** include your real BOT_TOKEN. Add it in Vercel dashboard or create a `.env` file locally.
